/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

/**
 *
 * @author User
 */
public class demo {
    
    public static void main(String[] args) {
        Thread serv=new Thread(new Server(12345));
        serv.start();
        
        try {
            serv.join();
        } catch (InterruptedException e) {
            System.out.println("Interrupted ...");
        }
    }
    
}
