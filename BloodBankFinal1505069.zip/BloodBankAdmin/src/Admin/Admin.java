/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class Admin extends Application{

    private Stage window;
    private Scene scene;
    private String windowTitle="Admin";
    
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        window=primaryStage;
        
        GridPane centre=new GridPane();
        
        Label adminLabel=new Label("Admin: ");
        TextField admin=new TextField();
        admin.setPromptText("Admin username");
        admin.setMinWidth(200);
        
        Label passwordLabel=new Label("Password: ");
        PasswordField password=new PasswordField();
        password.setPromptText("Admin password");
        
        
        window.setTitle(windowTitle);
        window.setScene(scene);
        window.show();
    }
    
}
