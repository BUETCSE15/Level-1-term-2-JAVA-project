/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import Subtasks.matchLogin;
import Subtasks.saveData;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class Connector implements Runnable {
    Socket socket;
    ObjectInputStream ois;
    ObjectOutputStream oos;
    Object obj;
    
    public Connector(Socket sock){
        socket=sock;
        try {
            ois=new ObjectInputStream(sock.getInputStream());
            oos=new ObjectOutputStream(socket.getOutputStream());
            obj=ois.readObject();
        } catch (Exception ex) {
            System.out.println("Unable to receive data from client\n" +ex);
        }
       
    }

    @Override
    public void run() {
        String data=obj.toString();
        
        System.out.println("Total String received: "+data);
        
        String[] subStrings=data.split(":");
        
        //System.out.println(subStrings[1] + " " + subStrings[2]);
        
        if(subStrings[0].equals("signUp")){
            saveData save=new saveData();
            save.putData(data);
        }else if(subStrings[0].equals("logIn"))
        {
            try {
                matchLogin match=new matchLogin(subStrings[1], subStrings[2]);
                
//                String sh="true@"+match.get();
//                String[] ans=sh.split("@");
//                System.out.println(ans[0] + " " + ans[1]);
                
                if(match.match()) oos.writeObject("true");
                else oos.writeObject("false");
                
            } catch (IOException ex) {
                System.out.println("Unable to send info to client\n" +ex);
            }
        }else if(subStrings[0].equals("update"))
        {
            String[] up=data.split(">");
            System.out.println("Splited : "+up[0]+ " "+up[1]+ " "+up[2]);
            
            updateData upData=new updateData(up[1], up[2]);
            upData.update();
            
            System.out.println("Data updated successfully");
        }else if(subStrings[0].equals("info"))
        {
            try {
                matchLogin match=new matchLogin(subStrings[1], subStrings[2]);
                match.match();
                String dataToSend="";
                dataToSend=match.get();
                
                //System.out.println("data to send: " + dataToSend);
                
                oos.writeObject(dataToSend);
            } catch (IOException ex) {
                System.out.println("Unable to send data\n"+ex);
            }
        }
        
    }
}
