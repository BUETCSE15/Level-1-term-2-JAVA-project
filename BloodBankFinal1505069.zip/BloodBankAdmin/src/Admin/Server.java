/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class Server implements Runnable {
    
    int port=12345;
    
    

    public Server(int p) {
        port=p;
    }
    
    public Server(){
        
    }

    @Override
    public void run() {
        
        
        try {
            ServerSocket serve=new ServerSocket(port);
            
            while(true){
                Socket socket=serve.accept();
                
                System.out.println("Client connected ->");
                
                Thread con=new Thread(new Connector(socket));
                con.start();
            }
        } catch (IOException ex) {
            System.out.println("Exception in main server");
        }
    }
    
}
